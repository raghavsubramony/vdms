import { Component } from '@angular/core';

@Component({
  selector: 'vm-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'Vehicle Data Management System';
}
