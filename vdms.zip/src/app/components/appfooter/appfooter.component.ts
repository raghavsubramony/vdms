import { Component, OnInit } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'vm-appfooter',
  templateUrl: './appfooter.component.html',
  styleUrls: ['./appfooter.component.css']
})
export class AppfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
