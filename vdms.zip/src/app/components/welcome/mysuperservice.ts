import { Injectable } from '@angular/core';

@Injectable()

export class MySuperService {
    public sidenav: any;

}