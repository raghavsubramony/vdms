import { AuthService } from './_services/_services/auth.service';
import { AuthGuard } from './_services/_services/auth_guard';


import { UserComponent } from './components/dashboard/user/user.component';
import { vehicleComponent } from './components/dashboard/vehicle/vehicle.component';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes, } from '@angular/router';
import { HashLocationStrategy,LocationStrategy } from '@angular/common';

import { DashboardComponent } from './components/dashboard/dashboard.component';
import { RegistrationPageComponent } from './components/RegistrationPage/RegistrationPage.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { AboutComponent } from './components/about/about.component';
import { HomeComponent } from './components/home/home.component';
import { Service1Component } from './components/service1/service1.component';
import { Service2Component } from './components/service2/service2.component';
import { Service3Component } from './components/service3/service3.component';
import { Service4Component } from './components/service4/service4.component';


const approutes: Routes = [
    
        {path: '',component: WelcomeComponent},
        {path: 'register', component: RegistrationPageComponent},
        {path: 'dashboard', component: DashboardComponent,pathMatch: 'full', canActivate: [AuthService]},
        {path:'about', component:AboutComponent},
        {path:'service_name1',component:Service1Component},
        {path:'service_name2',component:Service2Component},
        {path:'service_name3',component:Service3Component},
        {path:'service_name4',component:Service4Component},
        { path: 'vehicle', component:vehicleComponent, canActivate: [AuthService] },
        { path: 'user', component:UserComponent, canActivate: [AuthService] },
];

export const routing = RouterModule.forRoot(approutes)