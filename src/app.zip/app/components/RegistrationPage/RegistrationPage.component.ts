import { Component } from '@angular/core';
import { AuthService } from '../../_services/_services/auth.service';
import {Router} from "@angular/router";
@Component({
  selector: 'vm-registration',
  templateUrl: './RegistrationPage.component.html',
  styleUrls: ['./RegistrationPage.component.css']
})
export class RegistrationPageComponent {
  public error: any;
  constructor(private afService:AuthService , private router: Router) { }
	//registers the user and logs them in
  register(event, name, email, password) {
    event.preventDefault();
    this.afService.emailSignUp(email, password)
}
}