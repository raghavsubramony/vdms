import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vm-service1',
  templateUrl: './service1.component.html',
  styleUrls: ['./service1.component.css']
})
export class Service1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
