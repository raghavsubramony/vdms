import { Component } from '@angular/core';


@Component({
  moduleId:module.id,
  selector: 'vm-side-wrapper',
  templateUrl: './side-wrapper.component.html',
  styleUrls: ['./side-wrapper.component.css']
})
export class SideWrapper {

}