import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vm-service4',
  templateUrl: './service4.component.html',
  styleUrls: ['./service4.component.css']
})
export class Service4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
