import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vm-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  randomName(start: any) {
      if (start.opened) {
        start.close()
      } else {
        start.open();
      }
    
}
  constructor() {
    function openNav() {
      document.getElementById("mySidenav").style.display = "block";
  }
   }

  ngOnInit() {
  }

}
