import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'vehicle-cmp',
    moduleId: module.id,
    templateUrl: 'vehicle.component.html'
})

export class vehicleComponent implements OnInit{
    ngOnInit(){
        // $.getScript('../../../assets/js/material-dashboard.js');

    }
}
